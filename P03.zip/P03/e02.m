#
# O espaço de amostragem é S = { 5, 50, 100 }, representando retirar uma nota 
# de 5, 50, ou 100 da caixa
# 
# P(X=5) = 90/100 = 0.9
# P(X=50) = 9/100 = 0.09
# P(X=100) = 1/100 = 0.01
#

prob = [0.9 0.09 0.01];
stem(prob); #funçao massa de probabilidade de X